const char *ssid_1 = "CLARO_h9hU3j";
const char *password_1 = "7474FB19FD";
const char *ssid_2 = "Your_SSID_2";
const char *password_2 = "Your_Password_2";

// const char* BrokerMQTT = "broker.hivemq.com";
// const char *BrokerMQTT = "test.mosquitto.org";
const char* BrokerMQTT = "192.168.1.136";
const char *NombreESP = "DemoMQTT";