# Driver for QMP6988 digital temperature and pressure sensor

This driver is based on code of [original QMP6988 driver](https://github.com/m5stack/M5Unit-ENV)
by m5stack, made to be compatible with the i2cdev library (https://github.com/UncleRus/esp-idf-lib).
To convert the code a lot was reused from the sht3x component of the same "esp-idf-lib" library.