# Driver for SHT3x digital temperature and humidity sensor

This driver is fork of [original SHT3x driver](https://github.com/gschorcht/sht3x-esp-idf)
by Gunar Schorcht (@gschorcht), made to be compatible with the i2cdev library.
