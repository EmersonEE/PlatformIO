# `led_strip_spi`

A driver for SPI-based addressable LEDs.

Supported LEDs are:

- SK9822
- APA102 (not tested)
