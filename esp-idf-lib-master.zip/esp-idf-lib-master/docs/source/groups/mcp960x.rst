.. _mcp960x:

mcp960x - Driver for MCP9600/MCP9601, thermocouple EMF to temperature converter
===============================================================================

.. doxygengroup:: mcp960x
   :members:

