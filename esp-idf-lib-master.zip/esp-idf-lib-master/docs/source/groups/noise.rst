.. _noise:

noise - Simplex noise function
==============================

.. note:: This library was ported from FastLED

.. doxygengroup:: Noise
   :members:
