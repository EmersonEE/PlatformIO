.. _mcp342x:

mcp342x - Driver for 18-Bit, delta-sigma ADC MCP3426/MCP3427/MCP3428
====================================================================

.. doxygengroup:: mcp342x
   :members:

