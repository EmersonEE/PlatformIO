.. _framebuffer:

framebuffer - RGB framebuffer component
=======================================

.. doxygengroup:: framebuffer
   :members:
   
Animation
---------

.. doxygengroup:: animation
   :members:
